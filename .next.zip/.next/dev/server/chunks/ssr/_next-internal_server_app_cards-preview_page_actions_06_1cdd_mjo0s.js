module.exports = [
"[project]/.next-internal/server/app/cards-preview/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_cards-preview_page_actions_06_1cdd_mjo0s.js.map