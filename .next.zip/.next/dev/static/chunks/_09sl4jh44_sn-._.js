(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1q09-on_yew7c._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/node_modules_next_dist_1vlj9dmcq_-p-._.js","static/chunks/components_ui_0lr30vj2i3c_i._.js","static/chunks/_1bsprj1t0sacx._.css"],
    source: "entry"
});
